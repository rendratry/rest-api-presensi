package main

import (
	"fmt"
	"reflect"
	"testing"
	"time"
)

func TestEpoch(t *testing.T) {
	waktu := time.Now().UnixNano() / 1000000
	fmt.Println(waktu)
	fmt.Println(reflect.TypeOf(waktu))
}
