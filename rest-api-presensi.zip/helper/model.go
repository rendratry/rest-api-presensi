package helper

import (
	"golang/rest-api-presensi/entity/domain"
	"golang/rest-api-presensi/entity/web"
)

func ToCreateAkunResponse(user domain.User) web.CreateAkunResponse {
	return web.CreateAkunResponse{
		IdUser: user.IdUser,
		Email:  user.Email,
		Status: user.StatusLogin,
	}
}

func ToOtpResponse(otp domain.Otp) web.OtpResponse {
	return web.OtpResponse{
		Email:  otp.Email,
		NoHp:   otp.NoHp,
		Status: "OTP Terkirim",
	}
}

func ToOtpValidationResponse(otp domain.Otp) web.OtpValidationResponse {
	return web.OtpValidationResponse{
		Email:  otp.Email,
		Status: "Validated",
	}
}

func ToLoginResponse(nasabah domain.User) web.LoginResponse {
	return web.LoginResponse{
		IdUser: nasabah.IdUser,
		Email:  nasabah.Email,
		Status: nasabah.StatusLogin,
	}
}

func ToGetProfileResponse(user domain.User) web.GetProfileResponse {
	return web.GetProfileResponse{
		IdUser: user.IdUser,
		Email:  user.Email,
		Nama:   user.Nama,
		NoHp:   user.NoHp,
		Avatar: user.Avatar,
	}
}
