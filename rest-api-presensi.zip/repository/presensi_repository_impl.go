package repository

import (
	"context"
	"database/sql"
	"golang/rest-api-presensi/entity/domain"
	"golang/rest-api-presensi/helper"
)

type PresensiRepositoryImpl struct {
}

func NewPresensiRepositoryImpl() *PresensiRepositoryImpl {
	return &PresensiRepositoryImpl{}
}

func (repository *PresensiRepositoryImpl) PresensiMasuk(ctx context.Context, tx *sql.Tx, presensi domain.Presensi) string {
	script := "insert into presensi(id_user, tanggal_presensi, jam_masuk, keterangan, koordinat, alamat) values (?,?,?,?,?,?,?)"
	result, err := tx.ExecContext(ctx, script, presensi.IdUser, presensi.TanggalPresensi, presensi.JamMasuk, presensi.Keterangan, presensi.Koordinat, presensi.Alamat)
	helper.PanicIfError(err)

	id, err := result.LastInsertId()
	helper.PanicIfError(err)

	presensi.IdUser = int(id)

	return "Presensi Masuk Berhasil"
}

func (repository *PresensiRepositoryImpl) PresensiKeluar(ctx context.Context, tx *sql.Tx, presensi domain.Presensi) string {
	script := "update presensi set jam_pulang = ?, status_presensi = ? where id_user = ?"
	_, err := tx.ExecContext(ctx, script, presensi.JamPulang, presensi.Status, presensi.IdUser)
	helper.PanicIfError(err)
	return "Presensi Pulang Berhasil"
}
