package web

type CreateAkunResponse struct {
	IdUser int    `json:"id_user"`
	Email  string `json:"email"`
	Status string `json:"status"`
}

type LoginResponse struct {
	IdUser int    `json:"id_user"`
	Email  string `json:"email"`
	Status string `json:"status"`
}

type GetProfileResponse struct {
	IdUser int    `json:"id_user"`
	Email  string `json:"email"`
	Nama   string `json:"nama"`
	NoHp   string `json:"no_hp"`
	Avatar string `json:"avatar"`
}
