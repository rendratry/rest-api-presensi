package web

type PresensiMasukRequest struct {
	IdUser          int    `validate:"required" json:"id_user"`
	TanggalPresensi string `validate:"required" json:"tanggal_presensi"`
	JamMasuk        string `validate:"required" json:"jam_masuk"`
	Keterangan      string `validate:"required" json:"keterangan"`
	Koordinat       string `validate:"required" json:"koordinat"`
	Alamat          string `validate:"required" json:"alamat"`
}

type PresensiKeluarRequest struct {
	IdUser    int    `validate:"required" json:"id_user"`
	JamKeluar string `validate:"required" json:"jam_keluar"`
}
