package web

type PresensiMasukResponse struct {
	Keterangan string `json:"keterangan"`
}
