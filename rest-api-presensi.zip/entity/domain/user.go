package domain

type User struct {
	IdUser      int
	Email       string
	Nama        string
	NoHp        string
	Password    string
	StatusLogin string
	Avatar      string
}
