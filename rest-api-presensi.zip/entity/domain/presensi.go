package domain

type Presensi struct {
	IdUser          int
	TanggalPresensi string
	JamMasuk        string
	JamPulang       string
	Keterangan      string
	Koordinat       string
	Alamat          string
	Status          string
}
