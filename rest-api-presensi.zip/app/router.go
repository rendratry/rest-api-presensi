package app

import (
	"github.com/julienschmidt/httprouter"
	"golang/rest-api-presensi/controller"
	"golang/rest-api-presensi/exception"
)

func NewRouter(
	UserController controller.UserController,
	OtpController controller.OtpController,
) *httprouter.Router {

	router := httprouter.New()

	router.POST("/api/sendotp", OtpController.SendOtp)
	router.POST("/api/otpvalidation", OtpController.VerifikasiOtp)
	router.POST("/api/newaccount", UserController.CreateAkun)
	router.POST("/api/login", UserController.Login)
	router.GET("/api/profile/:userId", UserController.GetProfile)

	router.PanicHandler = exception.ErrorHandler

	return router

}
